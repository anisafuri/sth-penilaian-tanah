<h2 class="page-title">
    Data Reviewing
</h2>


<div class="row">
  <div class="col-md-6">
    <div class="card">
      <div class="card-body">
        <table class="table table-bordered table-striped">
          <tr>
            <th>ID Reviewing</th>
            <th><?php echo $reviewing['id_reviewing']; ?></th>
          </tr>
          <tr>
            <th>Nama Reviewer</th>
            <th><?php echo $reviewing['nama_peg']; ?></th>
          </tr>
          <tr>
            <th>Tanggal Reviewing</th>
            <th><?php echo $reviewing['tgl_reviewing']; ?></th>
          </tr>
          <tr>
            <th>ID Penilaian</th>
            <th><?php echo $reviewing['id_penilaian']; ?></th>
          </tr>
          <tr>
            <th>Status Reviewing</th>
            <th><?php echo $reviewing['status_reviewing']; ?></th>
          </tr>
          <tr>
            <th>Komentar</th>
            <th><?php echo $reviewing['komentar']; ?></th>
          </tr>
        </table>
      </div>
    </div>
  </div>
</div>
